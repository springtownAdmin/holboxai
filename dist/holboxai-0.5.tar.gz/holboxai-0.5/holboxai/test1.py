from s3_reader import S3DocReader
from csv_query import CsvQuery
import pandas as pd

# reader = S3DocReader()
# docs = reader.get_bucket("gen-ai-for-automotive")
# print(docs)

# ib = CsvQuery()
# query = "what is the total value"
# df = pd.read_csv("/home/ubuntu/RAG_API/csv_file/Air_Quality.csv")
# response = ib.single_csv_query(df, query)
# print(response) 