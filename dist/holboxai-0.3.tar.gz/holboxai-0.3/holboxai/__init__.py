from holboxai.file1 import firstclass
from holboxai.file2 import secondclass
from holboxai.file3 import sort