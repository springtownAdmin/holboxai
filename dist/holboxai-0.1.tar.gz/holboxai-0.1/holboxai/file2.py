import flask
import numpy as np

class secondclass:
    def demo():
        a = [1,2,3]
        a = np.array(a)
        print("here we show our live demo")
        print("sample numpy array: ", a)