import diffusers

class firstclass:
    def rag():
        print("here we do rag")